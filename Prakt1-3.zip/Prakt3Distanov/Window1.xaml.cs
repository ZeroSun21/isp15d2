﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Prakt3Distanov
{
    /// <summary>
    /// Логика взаимодействия для Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        private bool isDrawing;
        private Point lastPoint;
        private SolidColorBrush currentBrush;
        private double brushSize; 

        public Window1()
        {
            InitializeComponent();
            currentBrush = new SolidColorBrush(Colors.Black);
            brushSize = BrushSizeSlider.Value;
        }

        

        private void ColorComboBox_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            if (ColorComboBox.SelectedItem is ComboBoxItem selectedItem)
            {
                string colorName = selectedItem.Tag.ToString();
                currentBrush.Color = (Color)ColorConverter.ConvertFromString(colorName);
            }
        }

        private void BrushSizeSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            brushSize = e.NewValue;
        }

        private void DrawingCanvas_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ButtonState == MouseButtonState.Pressed)
            {
                isDrawing = true;
                lastPoint = e.GetPosition(DrawingCanvas);
                DrawingCanvas.CaptureMouse(); // Захват мыши
            }
        }

        private void DrawingCanvas_MouseMove(object sender, MouseEventArgs e)
        {
            if (isDrawing)
            {
                Point currentPoint = e.GetPosition(DrawingCanvas);
                DrawLine(lastPoint, currentPoint);
                lastPoint = currentPoint;
            }
        }

        private void DrawingCanvas_MouseUp(object sender, MouseButtonEventArgs e)
        {
            if (isDrawing)
            {
                isDrawing = false;
                DrawingCanvas.ReleaseMouseCapture(); // Освобождение мыши
            }
        }

        private void DrawLine(Point start, Point end)
        {
            Line line = new Line
            {
                Stroke = currentBrush,
                StrokeThickness = brushSize,
                X1 = start.X,
                Y1 = start.Y,
                X2 = end.X,
                Y2 = end.Y
            };
            DrawingCanvas.Children.Add(line);
        }

        private void Mode_Checked(object sender, RoutedEventArgs e)
        {
            // Здесь можно добавить логику для переключения режимов работы
            if (DrawMode.IsChecked == true)
            {
                // Режим рисования
            }
            else if (EditMode.IsChecked == true)
            {
                // Режим редактирования
            }
            else if (EraseMode.IsChecked == true)
            {
                // Режим удаления
            }
        }
    }
}

