﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace up_pr8
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            pr8_1 pr8_1 = new pr8_1();
            pr8_1.Show();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            pr8_2 pr8_2 = new pr8_2();
            pr8_2.Show();
        }
    }
}