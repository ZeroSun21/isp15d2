﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace up_pr7
{
    /// <summary>
    /// Логика взаимодействия для pr7_2.xaml
    /// </summary>
    public partial class pr7_2 : Window
    {
        private static Random random = new Random();
        public pr7_2()
        {
            InitializeComponent();
        }
        private void btnEscape_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
        {

            double currentLeft = Canvas.GetLeft(btnEscape);
            double currentTop = Canvas.GetTop(btnEscape);

            double newLeft = random.Next(50, 400);
            double newTop = random.Next(50, 250);

            var animationX = new DoubleAnimation
            {
                To = newLeft,
                Duration = TimeSpan.FromSeconds(0.2)
            };
            Storyboard.SetTarget(animationX, btnEscape);
            Storyboard.SetTargetProperty(animationX, new PropertyPath(Canvas.LeftProperty));

            var animationY = new DoubleAnimation
            {
                To = newTop,
                Duration = TimeSpan.FromSeconds(0.2)
            };
            Storyboard.SetTarget(animationY, btnEscape);
            Storyboard.SetTargetProperty(animationY, new PropertyPath(Canvas.TopProperty));

            Storyboard storyboard = new Storyboard();
            storyboard.Children.Add(animationX);
            storyboard.Children.Add(animationY);

            storyboard.Begin();
        }

        private void btnEscape_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
