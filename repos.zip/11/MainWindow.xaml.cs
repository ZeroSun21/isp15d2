﻿using Microsoft.Win32;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Effects;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace _11
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void LoadImages_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog
            {
                Multiselect = true,
                Filter = "Изображения (*.jpg;*.jpeg;*.png;*.bmp)|*.jpg;*.jpeg;*.png;*.bmp"
            };

            if (dialog.ShowDialog() == true)
            {
                ImagesPanel.Children.Clear(); // Очистим старые изображения

                foreach (string filePath in dialog.FileNames)
                {
                    ImagesPanel.Children.Add(CreateImageContainer(filePath));
                }
            }
        }

        private UIElement CreateImageContainer(string imagePath)
        {
            // Контейнер для изображения
            var border = new Border
            {
                Width = 200,
                Height = 200,
                Margin = new Thickness(10),
                Background = Brushes.White,
                CornerRadius = new CornerRadius(10),
                RenderTransformOrigin = new Point(0.5, 0.5),
                Cursor = System.Windows.Input.Cursors.Hand
            };

            var scaleTransform = new ScaleTransform(1, 1);
            var rotateTransform = new RotateTransform(0);
            var blurEffect = new BlurEffect { Radius = 5 };

            var transformGroup = new TransformGroup();
            transformGroup.Children.Add(scaleTransform);
            transformGroup.Children.Add(rotateTransform);
            border.RenderTransform = transformGroup;

            var image = new Image
            {
                Source = new BitmapImage(new Uri(imagePath)),
                Stretch = Stretch.UniformToFill,
                Effect = blurEffect
            };

            border.Child = image;

            // Анимации при наведении мыши
            border.MouseEnter += (s, e) =>
            {
                AnimateScale(scaleTransform, 1.1);
                AnimateBlur(blurEffect, 0);
                border.Effect = (Effect)this.Resources["ShadowEffect"];
            };

            border.MouseLeave += (s, e) =>
            {
                AnimateScale(scaleTransform, 1.0);
                AnimateBlur(blurEffect, 5);
                border.Effect = null;
            };

            var container = new StackPanel
            {
                Orientation = Orientation.Vertical,
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Center
            };

            var rotateLeft = new Button { Content = "⟲", Width = 50, Margin = new Thickness(2) };
            var rotateRight = new Button { Content = "⟳", Width = 50, Margin = new Thickness(2) };

            rotateLeft.Click += (s, e) => rotateTransform.Angle -= 90; // Поворот влево
            rotateRight.Click += (s, e) => rotateTransform.Angle += 90; // Поворот вправо

            var buttonPanel = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin = new Thickness(0, 5, 0, 0)
            };

            buttonPanel.Children.Add(rotateLeft);
            buttonPanel.Children.Add(rotateRight);

            var finalPanel = new StackPanel();
            finalPanel.Children.Add(border);
            finalPanel.Children.Add(buttonPanel);

            return finalPanel;
        }

        private void AnimateScale(ScaleTransform scale, double to)
        {
            var animX = new DoubleAnimation(to, TimeSpan.FromMilliseconds(300));
            var animY = new DoubleAnimation(to, TimeSpan.FromMilliseconds(300));
            scale.BeginAnimation(ScaleTransform.ScaleXProperty, animX);
            scale.BeginAnimation(ScaleTransform.ScaleYProperty, animY);
        }

        private void AnimateBlur(BlurEffect blur, double to)
        {
            var anim = new DoubleAnimation(to, TimeSpan.FromMilliseconds(300));
            blur.BeginAnimation(BlurEffect.RadiusProperty, anim);
        }
    }
}