﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace _13
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        DispatcherTimer timer = new DispatcherTimer();
        double angle = 0;

        UIElement[] elements;

        public MainWindow()
        {
            InitializeComponent();
            elements = new UIElement[] { vb1, vb2, vb3, vb4, vb5 };

            timer.Interval = TimeSpan.FromMilliseconds(30);
            timer.Tick += Timer_Tick;
            timer.Start();
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            double centerX = 400;
            double centerY = 300;
            double radiusX = 250;
            double radiusY = 100;

            int i = 0;
            foreach (var el in elements)
            {
                double localAngle = angle + i * 72; // 360 / 5 = 72°
                double radians = localAngle * Math.PI / 180;

                double x = centerX + radiusX * Math.Cos(radians);
                double y = centerY + radiusY * Math.Sin(radians);

                double scale = 0.5 + 0.5 * (1 - Math.Abs(y - centerY) / radiusY);
                double opacity = 0.3 + 0.7 * (1 - Math.Abs(y - centerY) / radiusY);

                Canvas.SetLeft(el, x - 50);
                Canvas.SetTop(el, y - 50);

                el.RenderTransform = new ScaleTransform(scale, scale);
                el.Opacity = opacity;

                i++;
            }

            angle += 1;
            if (angle >= 360) angle = 0;
        }
    }
}