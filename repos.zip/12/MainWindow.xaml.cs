﻿using System.Diagnostics;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace _12
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private DateTime _lastClickTime;
        private const int DoubleClickThreshold = 300;
        private bool _isAnimating = false;
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Sign_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            var currentTime = DateTime.Now;
            var elapsed = (currentTime - _lastClickTime).TotalMilliseconds;

            if (elapsed < DoubleClickThreshold)
            {
                Sign_OpenSvg(sender, e);
            }
            else
            {
                Sign_Click(sender, e);
            }

            _lastClickTime = currentTime;
        }

        private async void Sign_Click(object sender, MouseButtonEventArgs e)
        {
            if (_isAnimating) return;
            _isAnimating = true;

            if (sender is UIElement element)
            {
                var transformGroup = new TransformGroup();
                var scaleTransform = new ScaleTransform(1, 1);
                var translateTransform = new TranslateTransform();
                transformGroup.Children.Add(scaleTransform);
                transformGroup.Children.Add(translateTransform);
                element.RenderTransform = transformGroup;
                element.RenderTransformOrigin = new Point(0.5, 0.5);

                // Увеличение и перемещение
                var scaleUp = new DoubleAnimation(1.5, TimeSpan.FromMilliseconds(500));
                var moveRight = new DoubleAnimation(300, TimeSpan.FromMilliseconds(500));
                scaleTransform.BeginAnimation(ScaleTransform.ScaleXProperty, scaleUp);
                scaleTransform.BeginAnimation(ScaleTransform.ScaleYProperty, scaleUp);
                translateTransform.BeginAnimation(TranslateTransform.XProperty, moveRight);

                await Task.Delay(3000);

                // Возврат
                var scaleDown = new DoubleAnimation(1, TimeSpan.FromMilliseconds(500));
                var moveLeft = new DoubleAnimation(0, TimeSpan.FromMilliseconds(500));
                scaleTransform.BeginAnimation(ScaleTransform.ScaleXProperty, scaleDown);
                scaleTransform.BeginAnimation(ScaleTransform.ScaleYProperty, scaleDown);
                translateTransform.BeginAnimation(TranslateTransform.XProperty, moveLeft);

                await Task.Delay(500);
                _isAnimating = false;
            }
        }

        private void Sign_MouseEnter(object sender, MouseEventArgs e)
        {
            if (sender is Canvas canvas)
            {
                foreach (var child in canvas.Children)
                {
                    if (child is Shape shape)
                    {
                        if (shape.Fill is SolidColorBrush scb && scb.Color == Colors.White)
                        {
                            shape.Fill = Brushes.Yellow;
                        }
                    }
                }
            }
        }

        private void Sign_MouseLeave(object sender, MouseEventArgs e)
        {
            if (sender is Canvas canvas)
            {
                foreach (var child in canvas.Children)
                {
                    if (child is Shape shape && shape.Fill == Brushes.Yellow)
                    {
                        shape.Fill = Brushes.White;
                    }
                }
            }
        }

        private void Png_MouseEnter(object sender, MouseEventArgs e)
        {
            if (sender is Image image)
            {
                var fade = new DoubleAnimation(0.7, TimeSpan.FromMilliseconds(300));
                image.BeginAnimation(UIElement.OpacityProperty, fade);
            }
        }
        private void Png_MouseLeave(object sender, MouseEventArgs e)
        {
            if (sender is Image image)
            {
                var fade = new DoubleAnimation(1.0, TimeSpan.FromMilliseconds(300));
                image.BeginAnimation(UIElement.OpacityProperty, fade);
            }
        }

        private void Sign_OpenSvg(object sender, MouseButtonEventArgs e)
        {
            if (sender is FrameworkElement element && element.Tag is string tag)
            {
                // Получаем путь к SVG-файлу
                string relativePath = System.IO.Path.Combine("Signs", $"{tag}.svg");
                string fullPath = System.IO.Path.GetFullPath(relativePath);

                if (System.IO.File.Exists(fullPath))
                {
                    try
                    {
                        Process.Start(new ProcessStartInfo
                        {
                            FileName = fullPath,         // Абсолютный путь
                            UseShellExecute = true       // Важно! Открывает через ассоциированную программу
                        });
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Ошибка при открытии файла:\n{ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
                else
                {
                    MessageBox.Show($"SVG файл не найден:\n{fullPath}", "Файл не найден", MessageBoxButton.OK, MessageBoxImage.Warning);
                }
            }
        }
    }
}