﻿using System.Globalization;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System;

namespace _4_6
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        //Задание 3
        //    private void SliderFontSize_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        //    {
        //        TextBoxFontSize.Text = e.NewValue.ToString("F0");
        //    }

        //    private void TextBoxFontSize_TextChanged(object sender, TextChangedEventArgs e)
        //    {
        //        if (double.TryParse(TextBoxFontSize.Text, out double fontSize))
        //        {
        //            if (fontSize >= 8 && fontSize <= 30)
        //            {
        //                SliderFontSize.Value = fontSize;
        //            }
        //        }
        //    }
        //}
    }
}